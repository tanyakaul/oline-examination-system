function check()
{
var ques1=document.quiz.ques1.value;
var ques2=document.quiz.ques2.value;
var ques3=document.quiz.ques3.value;
var ques4=document.quiz.ques4.value;
var ques5=document.quiz.ques5.value;
var ques6=document.quiz.ques6.value;
var ques7=document.quiz.ques7.value;
var ques8=document.quiz.ques8.value;
var ques9=document.quiz.ques9.value;
var ques10=document.quiz.ques10.value;
var correct =0;
 
if (ques1=="a"){
correct=correct+1;
}
if (ques2=="4"){
correct=correct+1;
}
if (ques3=="d"){
correct=correct+1;
}
if (ques4=="none of these"){
correct=correct+1;
}
if (ques5=="A"){
correct=correct+1;
}
if (ques6=="c"){
correct=correct+1;
}
if (ques7=="d"){
correct=correct+1;
}
if (ques8=="a"){
correct=correct+1;
}
if (ques9=="c"){
correct=correct+1;
}
if (ques10=="a"){
correct=correct+1;
}
var messages =["Great job","Good job","You really need to do better"];
var score;

if (correct<5)
{ score=2;
}
if (correct>0 && correct<9)
{score=1;
}
if ( correct==10)
{score=0;
}
document.getElementById("message").innerHTML=messages[score];

document.getElementById("after_submit").style.visibility="visible";
document.getElementById("number_correct").innerHTML="You got "+ correct + " correct.";


}

var second =0;
var minute =0;
var timeleft=2*60;
function timeout()
{
  var minute= parseInt(timeleft/60);
  var second= parseInt(timeleft%60);
  if(timeleft<1)
    {
      clearTimeout(tm);
      document.getElementById("quiz").submit();
    }
  else
  { 
    if(minute<10)
      { 
        minute ="0"+minute;
      }
   document.getElementById("time").innerHTML=minute+":"+second;
  }
 timeleft--;
 var tm= setTimeout(function(){timeout()},1000);
}



function populate() {
    if(quiz.isEnded()) {
        showScores();
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;

        // show options
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i < choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess("btn" + i, choices[i]);
        }

        showProgress();
    }
};

function guess(id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        quiz.guess(guess);
        populate();
    }
};


function showProgress() {
    var currentQuestionNumber = quiz.questionIndex + 1;
    var element = document.getElementById("progress");
    element.innerHTML = "Question " + currentQuestionNumber + " of " + quiz.questions.length;
};

function showScores() {
    var gameOverHTML = "<h1>Result</h1>";
    gameOverHTML += "<h2 id='score'> Your scores:" + quiz.score + "</h2>";
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHTML;
};

// create questions
var questions = [
    new Question("Guess the brand C_D_RY?", ["Cadbury", "Cldury","Cadmry", "Cadiry"], "Cadbury"),
    new Question("What oil is characteristically used in the cooking of South India?", ["Canola", "Coconut", "Pineapple", "Olive"], "Coconut"),
    new Question("What is India�s national fruit?", ["Apple", "Banana","Mango", "Grapes"], "Mango"),
    new Question("What word is used in India for tea?", ["za", "chai", "ta", "All"], "chai"),
    new Question("Which of these foods does not originate in Mughal cuisine?", ["kebab", "samosa", "pilaf", "baba ghanoush"], "baba ghanoush")
];

// create quiz
var quiz = new Quiz(questions);

// display quiz
populate();